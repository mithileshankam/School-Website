# College Website — Git & GitHub Demonstration Project

A simple 4-page college website used to demonstrate Git basics: init/clone, commits,
branching, merging, and pushing to GitHub.

## Pages
- `index.html` — Home (hero banner + logo)
- `about.html` — About Us
- `gallery.html` — Gallery (added via the `gallery` feature branch)
- `contact.html` — Contact

## Images
All images in `images/` were generated for this project:
- `logo.png` — college emblem
- `banner.png` — home page hero banner
- `annual-day.jpg`, `sports-day.jpg`, `industrial-visit.jpg` — gallery cards

## Git Workflow Used

```
git init                      # or: git clone https://github.com/<username>/college-website.git
cd college-website

git add .
git commit -m "Initial college website"
git push origin main

git switch -c gallery
# add gallery.html + images, update nav links on other pages
git add .
git commit -m "Added Gallery page"
git push -u origin gallery

# On GitHub: open a Pull Request, review, merge gallery -> main

git switch main
git pull
git branch -d gallery
git push origin --delete gallery
```

## General Points
1. **Main** = stable code.
2. **Branch** = safe copy to develop a feature.
3. **Commit** = save a version.
4. **Push** = upload to GitHub.
5. **Merge** = bring an approved feature into main.
6. **Pull Request** = team review before merging.
